
import numpy as np
import sys
import copy
import time
import random
import argparse
######################################################

class thompsonAgent: 
    def __init__(self):
        self.name = "Terry the Thompson Sampling Agent"
    
    def recommendArm(self, bandit, history):
        #Hey, your code goes here!
        return False
