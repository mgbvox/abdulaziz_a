
import numpy as np
import sys
import copy
import time
import random
import argparse
######################################################

class alphaBetaAgent: 
    def __init__(self):
        self.name = "Allison the AlphaBetaAgent"
    
    def suggestMove(self, gameState):
        #Hey, your code goes here!
        return False
