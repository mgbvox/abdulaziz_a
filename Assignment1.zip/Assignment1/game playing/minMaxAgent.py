
import numpy as np
import sys
import copy
import time
import random
import argparse
######################################################

class minMaxAgent: 
    def __init__(self):
        self.name = "Manny the MinMaxAgent"
    
    def suggestMove(self, gameState):
        #Hey, your code goes here!
        return False
